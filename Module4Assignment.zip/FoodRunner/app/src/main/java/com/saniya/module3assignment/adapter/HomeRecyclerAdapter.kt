package com.saniya.module3assignment.adapter

import android.content.Context
import android.os.AsyncTask
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import androidx.room.Room
import com.saniya.module3assignment.R
import com.saniya.module3assignment.database.RestaurantDatabase
import com.saniya.module3assignment.database.RestaurantEntity
import com.saniya.module3assignment.model.Restaurant
import com.squareup.picasso.Picasso

class HomeRecyclerAdapter(val context: Context, val itemList: List<Restaurant>) :
    RecyclerView.Adapter<HomeRecyclerAdapter.HomeViewHolder>() {

    class HomeViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val txtRestaurantName: TextView = view.findViewById(R.id.txtRestaurantName)
        val txtRestaurantCostPerPerson: TextView =
            view.findViewById(R.id.txtRestaurantCostPerPerson)
        val txtRestaurantRating: TextView = view.findViewById(R.id.txtRestaurantRating)
        val imgRestaurant: ImageView = view.findViewById(R.id.imgRestaurant)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HomeViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.recycler_single_row, parent, false)
        return HomeViewHolder(view)
    }

    override fun getItemCount(): Int {
        return itemList.size
    }

    override fun onBindViewHolder(holder: HomeViewHolder, position: Int) {
        val restaurant = itemList[position]
        holder.txtRestaurantName.text = restaurant.restaurantName
        val money = "Rs. " + restaurant.restaurantCostPerPerson + " / person"
        holder.txtRestaurantCostPerPerson.text = money
        holder.txtRestaurantRating.text = restaurant.restaurantRating
        Picasso.get().load(restaurant.restaurantImgUrl).error(R.drawable.food_runner_logo_black)
            .into(holder.imgRestaurant)

        val restaurantEntity = RestaurantEntity(
            restaurant.restaurantId.toInt(),
            restaurant.restaurantName,
            restaurant.restaurantRating,
            restaurant.restaurantCostPerPerson,
            restaurant.restaurantImgUrl
        )

        if (!DbAsyncTask(context.applicationContext, restaurantEntity, 3).execute().get()) {
            holder.txtRestaurantRating.setCompoundDrawablesWithIntrinsicBounds(
                null,
                ContextCompat.getDrawable(context, R.drawable.ic_fav), null, null
            )
        } else {
            holder.txtRestaurantRating.setCompoundDrawablesWithIntrinsicBounds(
                null,
                ContextCompat.getDrawable(context, R.drawable.ic_fav_red), null, null
            )
        }

        holder.txtRestaurantRating.setOnClickListener {
            if (!DbAsyncTask(context.applicationContext, restaurantEntity, 3).execute().get()) {
                val addToFav = DbAsyncTask(context, restaurantEntity, 1).execute().get()
                if (addToFav) {
                    Toast.makeText(context, "Added to fav", Toast.LENGTH_SHORT).show()
                    holder.txtRestaurantRating.setCompoundDrawablesWithIntrinsicBounds(
                        null,
                        ContextCompat.getDrawable(
                            context.applicationContext,
                            R.drawable.ic_fav_red
                        ),
                        null,
                        null
                    )
                }
            } else {
                val removeFromFav = DbAsyncTask(context, restaurantEntity, 2).execute().get()
                if (removeFromFav) {
                    Toast.makeText(context, "Removed From fav", Toast.LENGTH_SHORT).show()
                    holder.txtRestaurantRating.setCompoundDrawablesWithIntrinsicBounds(
                        null,
                        ContextCompat.getDrawable(context.applicationContext, R.drawable.ic_fav),
                        null,
                        null
                    )
                }
            }
        }
    }

    class DbAsyncTask(val context: Context, val restaurantEntity: RestaurantEntity, val mode: Int) :
        AsyncTask<Void, Void, Boolean>() {
        override fun doInBackground(vararg params: Void?): Boolean {
            val db = Room.databaseBuilder(context, RestaurantDatabase::class.java, "restaurant-db")
                .build()
            when (mode) {
                1 -> {
                    db.restaurantDao().insertRestaurant(restaurantEntity)
                    db.close()
                    return true
                }
                2 -> {
                    db.restaurantDao().removeRestaurant(restaurantEntity)
                    db.close()
                    return true
                }
                3 -> {
                    val favBookId: RestaurantEntity? = db.restaurantDao()
                        .getRestaurantById(restaurantEntity.restaurant_id.toString())
                    db.close()
                    return favBookId != null
                }
            }
            return false
        }
    }
}