package com.saniya.module3assignment.activity

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.saniya.module3assignment.R
import com.saniya.module3assignment.fragment.ProfileFragment

class RegisterActivity : AppCompatActivity() {

    lateinit var etName : EditText
    lateinit var etEmail : EditText
    lateinit var etNumber: EditText
    lateinit var etAddress : EditText
    lateinit var etPassword : EditText
    lateinit var btnRegister : Button

    private val validNumber = "1234567890"
    private val validPassword = "bhoot"

    lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        supportActionBar?.title = "Register"

        etName = findViewById(R.id.etName)
        etEmail = findViewById(R.id.etEmail)
        etNumber = findViewById(R.id.etNumber)
        etAddress = findViewById(R.id.etAddress)
        etPassword = findViewById(R.id.etPassword)
        btnRegister = findViewById(R.id.btnRegister)

        sharedPreferences = getSharedPreferences(getString(R.string.login_preference), Context.MODE_PRIVATE)
        sharedPreferences.edit().putBoolean("isRegistered",false).apply()

        val isLoggedIn = sharedPreferences.getBoolean("isLoggedIn",false)

        if(isLoggedIn) {
            etNumber.setText(sharedPreferences.getString("Number", ""))
            etPassword.setText(sharedPreferences.getString("Password", ""))
        }

        btnRegister.setOnClickListener {
            if(etName.text.isNotEmpty() && etEmail.text.isNotEmpty() && etAddress.text.isNotEmpty()
                && etNumber.text.toString() == validNumber && etPassword.text.toString() == validPassword) {
                sharedPreferences.edit().putString("Name",etName.text.toString()).apply()
                sharedPreferences.edit().putString("Email",etEmail.text.toString()).apply()
                sharedPreferences.edit().putString("Location",etAddress.text.toString()).apply()
                if(!isLoggedIn) {
                    sharedPreferences.edit().putBoolean("isLoggedIn",true).apply()
                    sharedPreferences.edit().putString("Number",etNumber.text.toString()).apply()
                    sharedPreferences.edit().putString("Password",etPassword.text.toString()).apply()
                }
                Toast.makeText(this@RegisterActivity,"You have registered successfully.",Toast.LENGTH_SHORT).show()
                sharedPreferences.edit().putBoolean("isRegistered",true).apply()
                startActivity(Intent(this@RegisterActivity, MainActivity::class.java))
                finish()
            }
            else
                Toast.makeText(this@RegisterActivity,"Invalid credentials",Toast.LENGTH_SHORT).show()
        }
    }
}
