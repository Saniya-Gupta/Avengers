package com.saniya.module3assignment.activity

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import com.saniya.module3assignment.R

class LoginActivity : AppCompatActivity() {

    lateinit var etNumber: EditText
    lateinit var etPassword: EditText
    lateinit var txtForgotPassword: TextView
    lateinit var txtRegister: TextView
    lateinit var btnLogin: Button

    private val validNumber = "1234567890"
    private val validPassword = "bhoot"

    lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        title = "Login"

        etNumber = findViewById(R.id.etNumber)
        etPassword = findViewById(R.id.etPassword)
        txtForgotPassword = findViewById(R.id.txtForgotPassword)
        txtRegister = findViewById(R.id.txtRegister)
        btnLogin = findViewById(R.id.btnLogin)

        sharedPreferences =
            getSharedPreferences(getString(R.string.login_preference), Context.MODE_PRIVATE)
        val isLoggedIn = sharedPreferences.getBoolean("isLoggedIn", false)
        val isRegistered = sharedPreferences.getBoolean("isRegistered", false)

        Log.d("isLoggedIn: ", isLoggedIn.toString())
        Log.d("isRegistered: ", isRegistered.toString())

        if (isLoggedIn && isRegistered) {
            val intent = Intent(this@LoginActivity, MainActivity::class.java)
            startActivity(intent)
            finish()
        }

        btnLogin.setOnClickListener {

            if (etNumber.text.toString() == validNumber && etPassword.text.toString() == validPassword) {
                sharedPreferences.edit().putBoolean("isLoggedIn", true).apply()
                sharedPreferences.edit().putString("Number", etNumber.text.toString()).apply()
                sharedPreferences.edit().putString("Password", etPassword.text.toString()).apply()
                if(!isRegistered) {
                    val intent = Intent(this@LoginActivity, RegisterActivity::class.java)
                    startActivity(intent)
                }
                else {
                    val intent = Intent(this@LoginActivity, MainActivity::class.java)
                    startActivity(intent)
                    finish()
                }
            } else
                Toast.makeText(this@LoginActivity, "Invalid Credentials", Toast.LENGTH_SHORT).show()
        }

        txtForgotPassword.setOnClickListener {
            startActivity(
                Intent(
                    this@LoginActivity,
                    ForgotPasswordActivity::class.java
                )
            )
        }

        txtRegister.setOnClickListener {
            startActivity(
                Intent(
                    this@LoginActivity,
                    RegisterActivity::class.java
                )
            )
        }
    }

    override fun onPause() {
        if (sharedPreferences.getBoolean(
                "isLoggedIn",
                false
            ) && sharedPreferences.getBoolean("isRegistered", false)
        )
            finish()
        super.onPause()
    }
}
