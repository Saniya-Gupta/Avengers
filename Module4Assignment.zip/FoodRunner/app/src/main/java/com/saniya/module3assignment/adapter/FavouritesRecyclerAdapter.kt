package com.saniya.module3assignment.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.saniya.module3assignment.R
import com.saniya.module3assignment.database.RestaurantEntity
import com.squareup.picasso.Picasso

class FavouritesRecyclerAdapter(val context: Context, private val restaurantList: List<RestaurantEntity>) :
    RecyclerView.Adapter<FavouritesRecyclerAdapter.FavouritesViewHolder>() {

    class FavouritesViewHolder(view : View) : RecyclerView.ViewHolder(view) {
        val txtRestaurantName: TextView = view.findViewById(R.id.txtRestaurantName)
        val txtRestaurantCostPerPerson: TextView =
            view.findViewById(R.id.txtRestaurantCostPerPerson)
        val txtRestaurantRating: TextView = view.findViewById(R.id.txtRestaurantRating)
        val imgRestaurant: ImageView = view.findViewById(R.id.imgRestaurant)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FavouritesViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.recycler_single_row,parent,false)
        return FavouritesViewHolder(view)
    }

    override fun getItemCount(): Int {
        return restaurantList.size
    }

    override fun onBindViewHolder(holder: FavouritesViewHolder, position: Int) {
        val restaurant = restaurantList[position]
        holder.txtRestaurantName.text = restaurant.restaurantName
        holder.txtRestaurantCostPerPerson.text = restaurant.restaurantCostPerPerson
        holder.txtRestaurantRating.text = restaurant.restaurantRating
        Picasso.get().load(restaurant.restaurantImgUrl).error(R.drawable.food_runner_logo_black)
            .into(holder.imgRestaurant)

        val restaurantEntity = RestaurantEntity(
            restaurant.restaurant_id,
            restaurant.restaurantName,
            restaurant.restaurantRating,
            restaurant.restaurantCostPerPerson,
            restaurant.restaurantImgUrl
        )

        if (!HomeRecyclerAdapter.DbAsyncTask(context.applicationContext, restaurantEntity, 3).execute().get()) {
            holder.txtRestaurantRating.setCompoundDrawablesWithIntrinsicBounds(
                null,
                ContextCompat.getDrawable(context, R.drawable.ic_fav), null, null
            )
        } else {
            holder.txtRestaurantRating.setCompoundDrawablesWithIntrinsicBounds(
                null,
                ContextCompat.getDrawable(context, R.drawable.ic_fav_red), null, null
            )
        }

        holder.txtRestaurantRating.setOnClickListener {
            if (!HomeRecyclerAdapter.DbAsyncTask(context.applicationContext, restaurantEntity, 3).execute().get()) {
                val addToFav = HomeRecyclerAdapter.DbAsyncTask(context, restaurantEntity, 1).execute().get()
                if (addToFav) {
                    Toast.makeText(context, "Added to fav", Toast.LENGTH_SHORT).show()
                    holder.txtRestaurantRating.setCompoundDrawablesWithIntrinsicBounds(
                        null,
                        ContextCompat.getDrawable(
                            context.applicationContext,
                            R.drawable.ic_fav_red
                        ),
                        null,
                        null
                    )
                }
            } else {
                val removeFromFav = HomeRecyclerAdapter.DbAsyncTask(context, restaurantEntity, 2).execute().get()
                if (removeFromFav) {
                    Toast.makeText(context, "Removed From fav", Toast.LENGTH_SHORT).show()
                    holder.txtRestaurantRating.setCompoundDrawablesWithIntrinsicBounds(
                        null,
                        ContextCompat.getDrawable(context.applicationContext, R.drawable.ic_fav),
                        null,
                        null
                    )
                }
            }
        }
    }
}