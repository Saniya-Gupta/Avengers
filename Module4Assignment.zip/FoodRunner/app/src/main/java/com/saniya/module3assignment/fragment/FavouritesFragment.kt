package com.saniya.module3assignment.fragment

import android.content.Context
import android.os.AsyncTask
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.RelativeLayout
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.room.Room
import com.saniya.module3assignment.R
import com.saniya.module3assignment.adapter.FavouritesRecyclerAdapter
import com.saniya.module3assignment.adapter.HomeRecyclerAdapter
import com.saniya.module3assignment.database.RestaurantDatabase
import com.saniya.module3assignment.database.RestaurantEntity
import com.saniya.module3assignment.model.Restaurant
import kotlinx.android.synthetic.main.fragment_favourites.*

class FavouritesFragment : Fragment() {

    lateinit var recyclerFav: RecyclerView
    lateinit var layoutManager: RecyclerView.LayoutManager
    lateinit var recyclerAdapter : FavouritesRecyclerAdapter

    lateinit var progressLayout : RelativeLayout

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_favourites,container,false)
        recyclerFav = view.findViewById(R.id.recyclerFav)
        layoutManager = LinearLayoutManager(activity)
        progressLayout = view.findViewById(R.id.progressLayout)
        progressLayout.visibility = View.VISIBLE
        val favRestaurantList = DbAsyncTask(activity as Context).execute().get()
        if(favRestaurantList.isNotEmpty()) {
            progressLayout.visibility = View.INVISIBLE
            recyclerAdapter = FavouritesRecyclerAdapter(activity as Context, favRestaurantList)
            recyclerFav.adapter = recyclerAdapter
            recyclerFav.layoutManager = layoutManager
        }
        else {
            progressLayout.visibility = View.INVISIBLE
            Toast.makeText(activity as Context, "No fav",Toast.LENGTH_SHORT).show()
        }
        return view
    }

    class DbAsyncTask(val context: Context) : AsyncTask<Void, Void, List<RestaurantEntity>>() {
        override fun doInBackground(vararg params: Void?): List<RestaurantEntity> {
            val db = Room.databaseBuilder(context,RestaurantDatabase::class.java,"restaurant-db").build()
            return db.restaurantDao().getAllRestaurants()
        }
    }
}
