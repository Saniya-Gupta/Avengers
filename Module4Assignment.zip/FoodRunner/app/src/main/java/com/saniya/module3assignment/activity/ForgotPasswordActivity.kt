package com.saniya.module3assignment.activity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.saniya.module3assignment.R

class ForgotPasswordActivity : AppCompatActivity() {

    lateinit var etNumber : EditText
    lateinit var etEmail : EditText
    lateinit var btnNext : Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_forgot_password)

        title = "Forgot Password"

        etNumber = findViewById(R.id.etNumber)
        etEmail = findViewById(R.id.etEmail)
        btnNext = findViewById(R.id.btnNext)

        btnNext.setOnClickListener {
            Toast.makeText(this@ForgotPasswordActivity,"You clicked Next",Toast.LENGTH_SHORT).show()
        }
    }
}
