package com.saniya.module3assignment.fragment

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.os.AsyncTask
import android.os.Bundle
import android.provider.Settings
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.RelativeLayout
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.room.Room
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.saniya.module3assignment.R
import com.saniya.module3assignment.adapter.HomeRecyclerAdapter
import com.saniya.module3assignment.database.RestaurantDatabase
import com.saniya.module3assignment.database.RestaurantEntity
import com.saniya.module3assignment.model.Restaurant
import com.saniya.module3assignment.util.ConnectionManager
import org.json.JSONException

class HomeFragment : Fragment() {

    lateinit var recyclerHome: RecyclerView
    lateinit var layoutManager: RecyclerView.LayoutManager
    lateinit var recyclerAdapter: HomeRecyclerAdapter
    var restaurantInfoList: ArrayList<Restaurant> = arrayListOf()

    lateinit var progressLayout : RelativeLayout

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_home, container, false)
        recyclerHome = view.findViewById(R.id.recyclerHome)
        layoutManager = LinearLayoutManager(activity)

        progressLayout = view.findViewById(R.id.progressLayout)
        progressLayout.visibility = View.VISIBLE

        val queue = Volley.newRequestQueue(activity as Context)
        val url = "http://13.235.250.119/v2/restaurants/fetch_result/"

        if (ConnectionManager().checkConnectivity(activity as Context)) {
            val jsonObjectRequest = object : JsonObjectRequest(
                Request.Method.GET,
                url,
                null,
                Response.Listener {
                    try {
                        val dataobj = it.getJSONObject("data")
                        val success = dataobj.getBoolean("success")
                        if (success) {
                            progressLayout.visibility = View.GONE
                            val dataArray = dataobj.getJSONArray("data")
                            for (i in 0 until dataArray.length()) {
                                val jsonObj = dataArray.getJSONObject(i)
                                val restaurantObj = Restaurant(
                                    jsonObj.getString("id"),
                                    jsonObj.getString("name"),
                                    jsonObj.getString("rating"),
                                    jsonObj.getString("cost_for_one"),
                                    jsonObj.getString("image_url")
                                )
                                restaurantInfoList.add(restaurantObj)
                            }
                            recyclerAdapter =
                                HomeRecyclerAdapter(activity as Context, restaurantInfoList)
                            recyclerHome.adapter = recyclerAdapter
                            recyclerHome.layoutManager = layoutManager
                        } else
                            Toast.makeText(
                                activity as Context,
                                "Some error occurred",
                                Toast.LENGTH_SHORT
                            ).show()
                    } catch (e: JSONException) {
                        Toast.makeText(activity as Context, "JSON Error!!!", Toast.LENGTH_SHORT)
                            .show()
                    }
                },
                Response.ErrorListener {
                    Toast.makeText(activity as Context, "Volley Error", Toast.LENGTH_SHORT).show()
                }) {
                override fun getHeaders(): MutableMap<String, String> {
                    val headers = HashMap<String, String>()
                    headers["Content-Type"] = "application/json"
                    headers["token"] = "526f51e288db30 "
                    return headers
                }
            }
            queue.add(jsonObjectRequest)
        } else {
            val dialog = AlertDialog.Builder(activity as Context)
            dialog.setTitle("Error")
            dialog.setMessage("No Internet Connection Found")
            dialog.setPositiveButton("Open settings") { text, listener ->
                // Implicit Intent
                startActivity(Intent(Settings.ACTION_WIRELESS_SETTINGS))
                activity?.finish()
            }
            dialog.setNegativeButton("Exit App") { text, listener ->
                ActivityCompat.finishAffinity(activity as Activity)
            }
            dialog.create()
            dialog.show()
        }
        return view
    }
}
