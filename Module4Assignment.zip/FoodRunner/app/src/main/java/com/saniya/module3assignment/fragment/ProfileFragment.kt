package com.saniya.module3assignment.fragment

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView

import com.saniya.module3assignment.R

class ProfileFragment : Fragment() {

    lateinit var txtName: TextView
    lateinit var txtEmail: TextView
    lateinit var txtNum: TextView
    lateinit var txtPass: TextView
    lateinit var txtAdd: TextView

    lateinit var sharedPreferences: SharedPreferences

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_profile, container, false)

        txtName = view.findViewById(R.id.txtName)
        txtEmail = view.findViewById(R.id.txtEmail)
        txtNum = view.findViewById(R.id.txtNum)
        txtPass = view.findViewById(R.id.txtPass)
        txtAdd = view.findViewById(R.id.txtAdd)

        sharedPreferences = activity!!.getSharedPreferences(
            getString(R.string.login_preference), Context.MODE_PRIVATE)

        txtName.text = sharedPreferences.getString("Name", "Anonymous")
        txtEmail.text = sharedPreferences.getString("Email", "Anonymous")
        txtNum.text = sharedPreferences.getString("Number", "Anonymous")
        txtPass.text = sharedPreferences.getString("Password", "Anonymous")
        txtAdd.text = sharedPreferences.getString("Location", "Anonymous")

        return view
    }

}
