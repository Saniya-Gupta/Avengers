package com.saniya.module3assignment.activity

import android.content.Intent
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.view.View
import com.saniya.module3assignment.R

// Splash Screen
class SplashActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        // Hide the status bar.
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN

        // Hide the action bar
        actionBar?.hide()

        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            // Enable Transitions
        }

        else {
            // Swap without transitions
        }

        Handler().postDelayed({
            val intent = Intent(this@SplashActivity,
                LoginActivity::class.java)
            startActivity(intent)
            finish() // To finish the activity once it has started.
        },2000)
    }

    override fun onPause() {
        finish()
        super.onPause()
    }
}
